package com.nexohub.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.widget.Toast
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var overlay: LinearLayout
    private lateinit var overlayLabel: TextView
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private val home = "https://nexo-hub-app.pages.dev"
    private val homeHost = "nexo-hub-app.pages.dev"
    private val handler = Handler(Looper.getMainLooper())
    private val hideRun = Runnable { hideOverlay() }

    private val offlineHtml = """
        <html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>
        <body style="margin:0;background:#030504;color:#fff;font-family:sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;text-align:center">
        <h1 style="margin:0 20px 28px;letter-spacing:4px;font-size:26px">NO INTERNET</h1>
        <a href="app://reload" style="background:#35b84d;color:#fff;text-decoration:none;padding:14px 40px;border-radius:12px;font-weight:bold;letter-spacing:2px">RELOAD</a>
        </body></html>
    """.trimIndent()

    private fun hasNet(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun showOffline() {
        hideOverlay()
        web.loadDataWithBaseURL(null, offlineHtml, "text/html", "utf-8", null)
    }

    private fun showOverlay(url: String? = null) {
        val isHome = url == null || url.contains(homeHost)
        overlayLabel.text = if (isHome) "OPENING YOUR APP" else "PLEASE WAIT FOR A MOMENT"
        overlay.visibility = View.VISIBLE
        handler.removeCallbacks(hideRun)
        handler.postDelayed(hideRun, 45000)
    }

    private fun hideOverlay() {
        handler.removeCallbacks(hideRun)
        overlay.visibility = View.GONE
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#030504")
        window.navigationBarColor = Color.parseColor("#030504")

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#030504"))

        val d = resources.displayMetrics.density
        overlay = LinearLayout(this)
        overlay.orientation = LinearLayout.VERTICAL
        overlay.gravity = Gravity.CENTER
        overlay.setBackgroundColor(Color.parseColor("#F2030504"))
        overlay.visibility = View.GONE
        overlay.isClickable = true
        val bar = ProgressBar(this)
        bar.indeterminateTintList = ColorStateList.valueOf(Color.parseColor("#35b84d"))
        overlay.addView(bar, LinearLayout.LayoutParams((52 * d).toInt(), (52 * d).toInt()))
        val label = TextView(this)
        label.text = "OPENING YOUR APP"
        overlayLabel = label
        label.setTextColor(Color.WHITE)
        label.textSize = 15f
        label.typeface = Typeface.DEFAULT_BOLD
        label.letterSpacing = 0.15f
        label.gravity = Gravity.CENTER
        label.setPadding((20 * d).toInt(), (24 * d).toInt(), (20 * d).toInt(), 0)
        overlay.addView(label)

        val frame = FrameLayout(this)
        frame.addView(web, FrameLayout.LayoutParams(-1, -1))
        frame.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.javaScriptCanOpenWindowsAutomatically = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.allowFileAccess = false
        s.userAgentString = s.userAgentString + " NexoHubApp"
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (request == null) return false
                val u = request.url
                if (u.scheme == "app") {
                    if (hasNet()) {
                        showOverlay(home)
                        web.loadUrl(home)
                    } else {
                        Toast.makeText(this@MainActivity, "NO INTERNET", Toast.LENGTH_SHORT).show()
                    }
                    return true
                }
                if (request.isForMainFrame && !hasNet() && (u.scheme == "http" || u.scheme == "https")) {
                    showOffline()
                    return true
                }
                if (u.host == homeHost) return false
                val scheme = u.scheme ?: ""
                val isWeb = scheme == "http" || scheme == "https"
                val h = (u.host ?: "").lowercase()
                val needsOtherApp = h == "t.me" || h == "telegram.me" || h.endsWith("whatsapp.com") || h == "wa.me"
                if (!isWeb || needsOtherApp) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) {}
                    return true
                }
                if (request.isForMainFrame) showOverlay(u.toString())
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url != null && url.startsWith("http")) showOverlay(url)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                hideOverlay()
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) {
                    hideOverlay()
                    val code = error?.errorCode ?: 0
                    if (code == ERROR_HOST_LOOKUP || code == ERROR_CONNECT || code == ERROR_TIMEOUT || code == ERROR_IO) {
                        showOffline()
                    }
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(v: View?, cb: CustomViewCallback?) {
                if (customView != null) { cb?.onCustomViewHidden(); return }
                customView = v
                customCb = cb
                (window.decorView as ViewGroup).addView(
                    v, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            }

            override fun onHideCustomView() {
                customView?.let { (window.decorView as ViewGroup).removeView(it) }
                customView = null
                customCb?.onCustomViewHidden()
                customCb = null
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            }
        }

        web.setDownloadListener { url, _, _, _, _ ->
            try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) } catch (e: Exception) {}
        }

        if (b == null) {
            if (hasNet()) {
                showOverlay(home)
                web.loadUrl(home)
            } else {
                showOffline()
            }
        } else {
            web.restoreState(b)
        }
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        web.saveState(out)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> web.webChromeClient?.onHideCustomView()
            overlay.visibility == View.VISIBLE -> { web.stopLoading(); hideOverlay() }
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onPause() { super.onPause(); web.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
}
